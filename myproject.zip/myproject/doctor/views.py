from django.shortcuts import render

# Create your views here.
def contact(request):
    return render(request, 'doctor/contact.html')

def aboutus(request):
    return render(request, 'doctor/aboutus.html')