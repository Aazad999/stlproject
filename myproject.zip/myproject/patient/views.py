from django.shortcuts import render

# Create your views here.
def login(request):
    return render(request, 'patient/login.html')

def register(request):
    return render(request, 'patient/registration.html')

def appointment(request):
    return render(request, 'patient/appointment.html')